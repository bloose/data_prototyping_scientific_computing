## Air_sea
A python code to compute the Schmidt Number for common atmospheric gases.
