from setuptools import setup

setup(
    name = "air_sea",
    version = "0.1",
    author = "Brice Loose",
    packages=['air_sea'],
    install_requires=['numpy','scipy.io'],
)